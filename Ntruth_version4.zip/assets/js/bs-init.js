$(document).ready(function(){
	AOS.init();
	$('[data-bs-tooltip]').tooltip();
});